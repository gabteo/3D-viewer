#define STB_IMAGE_IMPLEMENTATION
#include "../includes/stb_image.h"