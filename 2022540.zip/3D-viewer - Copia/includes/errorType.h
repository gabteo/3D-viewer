#ifndef ERROR_TYPE_H
#define ERROR_TYPE_H

enum error_type_t 
{
    Success,
    Error
};

#endif