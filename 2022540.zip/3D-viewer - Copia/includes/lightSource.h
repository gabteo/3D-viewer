#ifndef LIGHTSOURCE_H
#define LIGHTSOURCE_H


class LightSource {
private:
    glm::vec3 lightColor;

public:

}

#endif