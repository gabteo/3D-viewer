#ifndef MYLIB_H
#define MYLIB_H

#include <GL/glew.h>
#include <GL/glut.h>
#include <GL/freeglut.h>

#include "gutils.h"
#include "shadersUtils.h"
#include "inputHandlers.h"
//#include "colors.h"

#endif
//#include "window.h"